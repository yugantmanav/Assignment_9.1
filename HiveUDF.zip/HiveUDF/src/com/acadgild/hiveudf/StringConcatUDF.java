package com.acadgild.hiveudf;

import java.util.ArrayList;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.Text;

public class StringConcatUDF extends UDF {

	private Text result = new Text();

	public Text evaluate(String sep, ArrayList<String> stringChars) {

		if (sep == null) {

			return null;

		}
		String tempstr = "";
		for (int i = 0; i <= stringChars.size() - 1; i++) {
			tempstr = tempstr + (stringChars.get(i) + sep);
		}

		String finalstr = tempstr.substring(0, tempstr.length() - 1);

		result.set(finalstr);

		return result;

	}

	public Text evaluate(Text str) {

		if (str == null) {

			return null;

		}

		result.set(StringUtils.strip(str.toString()));

		return result;

	}

}
